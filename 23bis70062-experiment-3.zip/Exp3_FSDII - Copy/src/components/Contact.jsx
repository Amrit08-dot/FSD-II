export default function Contact() {
  return <h2>Contact Page</h2>;
}